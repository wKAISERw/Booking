<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Booking System</title>
</head>
<body>
<h1>Welcome to the Booking System!</h1>
</body>
</html>
